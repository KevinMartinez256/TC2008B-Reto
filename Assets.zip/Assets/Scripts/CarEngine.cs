using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CarEngine : MonoBehaviour{
    
    public Transform path;
    public float maxSteerAngle = 45f;
    public WheelCollider FrontLeftTire;
    public WheelCollider FrontRightTire;
    public WheelCollider BackLeftTire;
    public WheelCollider BackRightTire;
    public float maxMotorTorque = 30f;
    public float maxBrakeTorque = 100f;
    public float currentSpeed;
    public float maxSpeed = 50f;
    public Vector3 centerOfMass;
    public bool isBraking = false;

    [Header("Sensors")]
    public float sensorLength = 1.5f;
    public float frontSensorPosition = 1.2f;
    public float frontSideSensorPosition = 0.2f;
    public float frontSensorAngle = 30f;
    public float sensorYOffset = 0.25f;  // Sensor height offset

    private List<Transform> nodes;
    private int currectNode = 0;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start(){
        GetComponent<Rigidbody>().centerOfMass = centerOfMass;

        Transform[] pathTransforms = path.GetComponentsInChildren<Transform>();
        nodes = new List<Transform>();

        for (int i = 0; i < pathTransforms.Length; i++){
            if(pathTransforms[i] != path.transform){
                nodes.Add(pathTransforms[i]);
            }
        }
    }

    // Update is called once per frame
    private void Update(){
        Sensors();
        ApplySteer();
        Drive();
        Braking();
        CheckWaypointDistance();
    }

    private void Sensors(){
        bool obstacleDetected = false; // Flag to determine if any sensor detects an obstacle
        RaycastHit hit;

        // Base sensor start position with Y offset
        Vector3 baseSensorPos = transform.position + transform.forward * frontSensorPosition + Vector3.up * sensorYOffset;
        
        // 1. Front Center Sensor
        Vector3 sensorDirection = transform.forward;
        Vector3 sensorEndPos = baseSensorPos + sensorDirection * sensorLength;
        if (Physics.Raycast(baseSensorPos, sensorDirection, out hit, sensorLength)){
            sensorEndPos = hit.point;
            obstacleDetected = true;
        }
        Debug.DrawLine(baseSensorPos, sensorEndPos, Color.green);

        // 2. Front Right Sensor
        Vector3 rightSensorPos = baseSensorPos + transform.right * frontSideSensorPosition;
        sensorDirection = transform.forward;
        sensorEndPos = rightSensorPos + sensorDirection * sensorLength;
        if (Physics.Raycast(rightSensorPos, sensorDirection, out hit, sensorLength)){
            sensorEndPos = hit.point;
            obstacleDetected = true;
        }
        Debug.DrawLine(rightSensorPos, sensorEndPos, Color.green);

        // 3. Front Right Angle Sensor
        sensorDirection = Quaternion.AngleAxis(frontSensorAngle, transform.up) * transform.forward;
        sensorEndPos = rightSensorPos + sensorDirection * sensorLength;
        if (Physics.Raycast(rightSensorPos, sensorDirection, out hit, sensorLength)){
            sensorEndPos = hit.point;
            obstacleDetected = true;
        }
        Debug.DrawLine(rightSensorPos, sensorEndPos, Color.red);

        // 4. Front Left Sensor
        Vector3 leftSensorPos = baseSensorPos - transform.right * frontSideSensorPosition;
        sensorDirection = transform.forward;
        sensorEndPos = leftSensorPos + sensorDirection * sensorLength;
        if (Physics.Raycast(leftSensorPos, sensorDirection, out hit, sensorLength)){
            sensorEndPos = hit.point;
            obstacleDetected = true;
        }
        Debug.DrawLine(leftSensorPos, sensorEndPos, Color.green);

        // 5. Front Left Angle Sensor
        sensorDirection = Quaternion.AngleAxis(-frontSensorAngle, transform.up) * transform.forward;
        sensorEndPos = leftSensorPos + sensorDirection * sensorLength;
        if (Physics.Raycast(leftSensorPos, sensorDirection, out hit, sensorLength)){
            sensorEndPos = hit.point;
            obstacleDetected = true;
        }
        Debug.DrawLine(leftSensorPos, sensorEndPos, Color.yellow);

        // If any sensor detects an obstacle, set braking to true
        isBraking = obstacleDetected;
    }

    private void ApplySteer(){
        Vector3 relativeVector = transform.InverseTransformPoint(nodes[currectNode].position);
        float newSteer = (relativeVector.x / relativeVector.magnitude) * maxSteerAngle;
        FrontLeftTire.steerAngle = newSteer;
        FrontRightTire.steerAngle = newSteer;
    }
    
    private void Drive(){
        currentSpeed = 2 * Mathf.PI * FrontLeftTire.radius * FrontLeftTire.rpm * 60 / 1000;

        if(currentSpeed < maxSpeed && !isBraking) {
            FrontLeftTire.motorTorque = maxMotorTorque;
            FrontRightTire.motorTorque = maxMotorTorque;
        }
        else {
            FrontLeftTire.motorTorque = 0;
            FrontRightTire.motorTorque = 0;
        }
    }

    private void CheckWaypointDistance(){
        if(Vector3.Distance(transform.position, nodes[currectNode].position) < 0.5f) {
            if(currectNode == nodes.Count - 1){
                currectNode = 0;
            }
            else {
                currectNode++;
            }
        }
    }

    private void Braking(){
        if (isBraking){
            BackLeftTire.brakeTorque = maxBrakeTorque;
            BackRightTire.brakeTorque = maxBrakeTorque;
        }
        else{
            BackLeftTire.brakeTorque = 0;
            BackRightTire.brakeTorque = 0;
        }
    }
}
