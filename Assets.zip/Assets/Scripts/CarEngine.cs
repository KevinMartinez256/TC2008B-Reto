using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CarEngine : MonoBehaviour{
    
    public Transform path;
    public float maxSteerAngle = 45f;
    public WheelCollider FrontLeftTire;
    public WheelCollider FrontRightTire;
    public WheelCollider BackLeftTire;
    public WheelCollider BackRightTire;
    public float maxMotorTorque = 30f;
    public float maxBrakeTorque = 100f;
    public float currentSpeed;
    public float maxSpeed = 50f;
    public Vector3 centerOfMass;
    public bool isBraking = false;

    private List<Transform> nodes;
    private int currectNode = 0;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start(){
        GetComponent<Rigidbody>().centerOfMass = centerOfMass;

        Transform[] pathTransforms = path.GetComponentsInChildren<Transform>();
        nodes = new List<Transform>();

        for (int i = 0; i < pathTransforms.Length; i++){
            if(pathTransforms[i] != path.transform){
                nodes.Add(pathTransforms[i]);
            }
        }
    }

    // Update is called once per frame
    private void Update(){
        ApplySteer();
        Drive();
        Braking();
        CheckWaypointDistance();
    }

    private void ApplySteer(){
        Vector3 relativeVector = transform.InverseTransformPoint(nodes[currectNode].position);
        float newSteer = (relativeVector.x / relativeVector.magnitude) * maxSteerAngle;
        FrontLeftTire.steerAngle = newSteer;
        FrontRightTire.steerAngle = newSteer;
    }
    
    private void Drive(){
        currentSpeed = 2 * Mathf.PI * FrontLeftTire.radius * FrontLeftTire.rpm * 60 / 1000;

        if(currentSpeed < maxSpeed && !isBraking) {
            FrontLeftTire.motorTorque = maxMotorTorque;
            FrontRightTire.motorTorque = maxMotorTorque;
        }
        else {
            FrontLeftTire.motorTorque = 0;
            FrontRightTire.motorTorque = 0;
        }
    }

    private void CheckWaypointDistance(){
        if(Vector3.Distance(transform.position, nodes[currectNode].position) < 0.5f) {
            if(currectNode == nodes.Count - 1){
                currectNode = 0;
            }
            else {
                currectNode++;
            }
        }
    }

    private void Braking(){
        if (isBraking){
            BackLeftTire.brakeTorque = maxBrakeTorque;
            BackRightTire.brakeTorque = maxBrakeTorque;
        }
        else{
            BackLeftTire.brakeTorque = 0;
            BackRightTire.brakeTorque = 0;
        }
    }
}
